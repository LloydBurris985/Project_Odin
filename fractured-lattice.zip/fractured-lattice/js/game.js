const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Resize canvas to fill screen
function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// Setup Dev Squad components
const input = new InputHandler();
// Simple temporary object for stars/lattice points
const stars = [];
for (let i = 0; i < 150; i++) {
    stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        depth: Math.random() * 0.8 + 0.2 // Fake depth multiplier
    });
}

// Game Loop
function update() {
    const move = input.getMovement();
    const speed = 5;

    // Move the universe around the ship to create the 3D depth illusion!
    stars.forEach(star => {
        star.x -= move.x * speed * star.depth;
        star.y -= move.y * speed * star.depth;

        // Wrap around screen boundaries smoothly
        if (star.x < 0) star.x = canvas.width;
        if (star.x > canvas.width) star.x = 0;
        if (star.y < 0) star.y = canvas.height;
        if (star.y > canvas.height) star.y = 0;
    });

    // Clear Screen
    ctx.fillStyle = '#05050a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw Space Parallax
    stars.forEach(star => {
        // Deeper stars are smaller and dimmer
        const size = star.depth * 3;
        const alpha = star.depth;
        ctx.fillStyle = `rgba(200, 220, 255, ${alpha})`;
        ctx.fillRect(star.x, star.y, size, size);
    });

    // Draw Placeholder Cartoon Ship in the dead center
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    ctx.save();
    ctx.translate(centerX, centerY);

    // Dynamic flipbook lean depending on direction
    if (move.x < 0) ctx.scale(0.8, 1); // Lean left
    if (move.x > 0) ctx.scale(0.8, 1); // Lean right

    // Drawing a retro vector fighter layout
    ctx.strokeStyle = '#00ffcc';
    ctx.lineWidth = 3;
    ctx.fillStyle = '#0a1a2f';
    ctx.beginPath();
    ctx.moveTo(0, -25);  // Nose cone
    ctx.lineTo(20, 20);  // Right wing
    ctx.lineTo(0, 10);   // Thruster core
    ctx.lineTo(-20, 20); // Left wing
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Engine glow flare
    ctx.fillStyle = move.y < 0 ? '#ff3300' : '#ffaa00';
    ctx.beginPath();
    ctx.arc(0, 15, move.y < 0 ? 10 : 5, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();

    requestAnimationFrame(update);
}

// Ignition!
requestAnimationFrame(update);

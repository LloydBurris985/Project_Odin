class InputHandler {
    constructor() {
        this.keys = {};
        this.touch = { startX: 0, startY: 0, x: 0, y: 0, isDragging: false };

        // Desktop Keyboard
        window.addEventListener('keydown', (e) => this.keys[e.key.toLowerCase()] = true);
        window.addEventListener('keyup', (e) => this.keys[e.key.toLowerCase()] = false);

        // Safe Mobile Touch initialization
        window.addEventListener('DOMContentLoaded', () => {
            const overlay = document.getElementById('touchOverlay');
            if (!overlay) return;

            overlay.addEventListener('touchstart', (e) => {
                this.touch.startX = e.touches[0].clientX;
                this.touch.startY = e.touches[0].clientY;
                this.touch.isDragging = true;
            }, { passive: true });

            overlay.addEventListener('touchmove', (e) => {
                if (!this.touch.isDragging) return;
                this.touch.x = e.touches[0].clientX - this.touch.startX;
                this.touch.y = e.touches[0].clientY - this.touch.startY;
            }, { passive: true });

            overlay.addEventListener('touchend', () => {
                this.touch.x = 0;
                this.touch.y = 0;
                this.touch.isDragging = false;
            });
        });
    }

    getMovement() {
        let mx = 0;
        let my = 0;

        if (this.keys['a'] || this.keys['arrowleft']) mx = -1;
        if (this.keys['d'] || this.keys['arrowright']) mx = 1;
        if (this.keys['w'] || this.keys['arrowup']) my = -1;
        if (this.keys['s'] || this.keys['arrowdown']) my = 1;

        if (this.touch.isDragging) {
            const threshold = 15; 
            if (Math.abs(this.touch.x) > threshold) mx = Math.sign(this.touch.x);
            if (Math.abs(this.touch.y) > threshold) my = Math.sign(this.touch.y);
        }

        return { x: mx, y: my };
    }
}

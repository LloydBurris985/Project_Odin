export const ASSET_REGISTRY = {
  images: {
    dockManager: './assets/images/80061.png',
    hudView: './assets/images/80059.png',
    playerShip: './assets/images/80048.png',
    explosion: './assets/images/80115.png'
  },
  audio: {
    loreIntro: './assets/audio/lore_intro.mp3',
    dockManagerVoice: './assets/audio/TTSOL-en-HK-Sam-20260722-105405.mp3',
    combatMusic: './assets/audio/TTSOL-en-KE-Chilemba-20260722-103056.mp3'
  }
};

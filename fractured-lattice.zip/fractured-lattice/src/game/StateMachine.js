export class GameStateMachine {
  constructor(engine) {
    this.engine = engine;
    this.states = {};
    this.currentState = null;
  }

  registerState(name, stateInstance) {
    this.states[name] = stateInstance;
    stateInstance.machine = this;
    stateInstance.engine = this.engine;
  }

  changeState(name, params = {}) {
    if (this.currentState && this.currentState.exit) {
      this.currentState.exit();
    }
    this.currentState = this.states[name];
    if (this.currentState && this.currentState.enter) {
      this.currentState.enter(params);
    }
  }

  update(dt) {
    if (this.currentState && this.currentState.update) {
      this.currentState.update(dt);
    }
  }

  render(ctx) {
    if (this.currentState && this.currentState.render) {
      this.currentState.render(ctx);
    }
  }

  handleInput(input) {
    if (this.currentState && this.currentState.handleInput) {
      this.currentState.handleInput(input);
    }
  }
}

// --- THE FRACTURED LATTICE: ENHANCED GAME ENGINE ---

const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d');
document.body.appendChild(canvas);

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

let currentState = 'INTRO'; // INTRO, DOCK_MANAGER, DOCK_EXTERIOR, PRE_COMBAT, COMBAT, PLAYER_EXPLOSION, EJECTED, EXPLOSION, POST_COMBAT, WARP, FINAL
let gameEnded = false;
let lastTapTime = 0;

// Image Assets
const images = {
    dock: new Image(),
    ship: new Image(),
    explosion: new Image(),
    target: new Image(),
    finalStation: new Image()
};
images.dock.src = 'assets/images/dockmanager.png';
images.ship.src = 'assets/images/myship.png';
images.explosion.src = 'assets/images/explosion.png';
images.target.src = 'assets/images/target.png';
images.finalStation.src = 'assets/images/grok_image_xokn3wv.jpg';

// Verified Audio Files
const audio = {
    introLore: new Audio('assets/audio/TTSOL-en-KE-Chilemba-20260722-103056.mp3'),
    dockSam: new Audio('assets/audio/TTSOL-en-HK-Sam-20260722-105405.mp3'),
    warmRack: new Audio('assets/audio/TTSOL-en-KE-Chilemba-20260722-104453.mp3'),
    ariaPreCombat: new Audio('assets/audio/TTSOL-en-US-Aria-20260730-223801.mp3'),
    kineticRods: new Audio('assets/audio/kinetic_rods.mp3'),
    ariaDestroyedLoss: new Audio('assets/audio/TTSOL-en-US-Aria-20260730-224714.mp3'),
    ariaPost1: new Audio('assets/audio/TTSOL-en-US-Aria-20260730-224458.mp3'),
    ariaPost2: new Audio('assets/audio/TTSOL-en-US-Aria-20260730-224818.mp3'),
    muninnConsole: new Audio('assets/audio/muninn_s_console.mp3'),
    blueLightCabin: new Audio('assets/audio/blue_light_cabin.mp3')
};

for (let k in audio) { audio[k].preload = 'auto'; }

function stopAllAudio() {
    for (let k in audio) {
        audio[k].pause();
        audio[k].currentTime = 0;
        audio[k].onended = null;
    }
}

// Synthesized Laser SFX
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function playLaserSFX(freqStart, freqEnd) {
    if (!audioCtx) return;
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(freqStart, audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(freqEnd, audioCtx.currentTime + 0.1);
    gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.1);
}

// Starfield
const stars = Array.from({ length: 60 }, () => ({
    x: Math.random(),
    y: Math.random(),
    size: Math.random() * 2 + 1,
    speed: Math.random() * 0.003 + 0.001
}));

// Entity States
let playerShip = { x: window.innerWidth / 2, y: window.innerHeight - 100, hp: 100, maxHp: 100 };
let aiShip = { x: window.innerWidth / 2, y: 120, radius: 30, dirX: 3, hp: 100, maxHp: 100 };
let playerProjectiles = [];
let aiProjectiles = [];
let aiShootTimer = 0;
let ejectCapsuleY = 0;

function resetEntities() {
    playerShip.x = window.innerWidth / 2;
    playerShip.y = window.innerHeight - 100;
    playerShip.hp = 100;
    aiShip.x = window.innerWidth / 2;
    aiShip.y = 120;
    aiShip.hp = 100;
    playerProjectiles = [];
    aiProjectiles = [];
}

// Story Crawl Text
const rawParagraphs = [
    "THE FRACTURED LATTICE", "",
    "It has already begun.", "",
    "Before time itself, the Lattice was perfect — an infinite repository where every timeline coexisted.", "",
    "Advanced civilizations lived in peace… until he came.", "",
    "He forged Zork… and unleashed an AI army that spread across realities.", "",
    "Now settlers return to eradicate remaining AI forces and restore balance.", "",
    "You were promised a ship, three meals a day, a bunk, and steady pay.", "",
    "Your patrol begins today.", "",
    "Welcome to The Fractured Lattice."
];
let scrollY = canvas.height;

function wrapText(text, maxWidth, font) {
    ctx.font = font;
    if (!text) return [""];
    const words = text.split(' ');
    const lines = [];
    let currentLine = words[0];
    for (let i = 1; i < words.length; i++) {
        if (ctx.measureText(currentLine + " " + words[i]).width < maxWidth) {
            currentLine += " " + words[i];
        } else {
            lines.push(currentLine);
            currentLine = words[i];
        }
    }
    lines.push(currentLine);
    return lines;
}

// Audio Pipelines
function startDockManagerAudio() {
    stopAllAudio();
    audio.dockSam.play().then(() => {
        audio.dockSam.onended = () => {
            setTimeout(() => {
                if (currentState === 'DOCK_MANAGER') {
                    currentState = 'DOCK_EXTERIOR';
                }
            }, 600); // Small pause before outside view
        };
    }).catch(() => {});
}

function startScene4Audio() {
    stopAllAudio();
    audio.warmRack.play().then(() => {
        audio.warmRack.onended = () => {
            setTimeout(() => {
                audio.ariaPreCombat.play().then(() => {
                    audio.ariaPreCombat.onended = () => {
                        setTimeout(() => {
                            audio.kineticRods.loop = true;
                            audio.kineticRods.play().catch(e => console.log(e));
                            currentState = 'COMBAT';
                        }, 600);
                    };
                }).catch(() => { currentState = 'COMBAT'; });
            }, 600);
        };
    }).catch(() => { currentState = 'COMBAT'; });
}

function handlePlayerDefeat() {
    stopAllAudio();
    currentState = 'PLAYER_EXPLOSION';
    ejectCapsuleY = playerShip.y;
    setTimeout(() => {
        currentState = 'EJECTED';
        audio.ariaDestroyedLoss.play().then(() => {
            audio.ariaDestroyedLoss.onended = () => {
                gameEnded = true;
            };
        }).catch(() => { gameEnded = true; });
    }, 1000);
}

function startPostCombatPipeline() {
    stopAllAudio();
    currentState = 'POST_COMBAT';
    
    audio.ariaPost1.play().then(() => {
        audio.ariaPost1.onended = () => {
            setTimeout(() => {
                audio.ariaPost2.play().then(() => {
                    audio.ariaPost2.onended = () => {
                        setTimeout(startWarpScene, 600);
                    };
                }).catch(startWarpScene);
            }, 600);
        };
    }).catch(startWarpScene);
}

function startWarpScene() {
    stopAllAudio();
    currentState = 'WARP';
    
    audio.muninnConsole.play().then(() => {
        audio.muninnConsole.onended = () => {
            setTimeout(() => {
                audio.blueLightCabin.play().then(() => {
                    audio.blueLightCabin.onended = () => {
                        setTimeout(() => {
                            currentState = 'FINAL';
                        }, 600);
                    };
                }).catch(() => { currentState = 'FINAL'; });
            }, 600);
        };
    }).catch(() => { currentState = 'FINAL'; });
}

// Touch Handling
function handleTouchMove(e) {
    if (currentState === 'COMBAT' && e.touches.length > 0) {
        playerShip.x = e.touches[0].clientX;
    }
}

function handleTap(e) {
    if (gameEnded) return;
    const now = Date.now();
    if (now - lastTapTime < 250) return;
    lastTapTime = now;

    if (audioCtx.state === 'suspended') audioCtx.resume();

    // SCENE 1 & 2: INTRO
    if (currentState === 'INTRO') {
        if (audio.introLore.paused) {
            audio.introLore.play().catch(err => console.log(err));
        } else {
            currentState = 'DOCK_MANAGER';
            startDockManagerAudio();
        }
    // SCENE 3 PART 1 -> PART 2
    } else if (currentState === 'DOCK_MANAGER') {
        currentState = 'DOCK_EXTERIOR';
    // SCENE 3 PART 2 -> SCENE 4
    } else if (currentState === 'DOCK_EXTERIOR') {
        currentState = 'PRE_COMBAT';
        startScene4Audio();
    // SCENE 5 COMBAT
    } else if (currentState === 'COMBAT') {
        playLaserSFX(850, 150);
        playerProjectiles.push({ x: playerShip.x, y: playerShip.y - 30 });
    // SCENE 9 MISSION BOARD
    } else if (currentState === 'FINAL') {
        const tapY = e.touches && e.touches.length > 0 ? e.touches[0].clientY : e.clientY;
        if (tapY > canvas.height - 70) {
            gameEnded = true;
            stopAllAudio();
            ctx.fillStyle = '#000000';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#ffaa00';
            ctx.font = '18px monospace';
            ctx.textAlign = 'center';
            ctx.fillText("SESSION TERMINATED - GAME CLOSED", canvas.width / 2, canvas.height / 2);
        } else if (tapY > canvas.height - 130) {
            resetEntities();
            currentState = 'DOCK_MANAGER';
            startDockManagerAudio();
        }
    }
}

window.addEventListener('touchstart', handleTap, { passive: false });
window.addEventListener('touchmove', handleTouchMove, { passive: false });
window.addEventListener('mousedown', (e) => {
    if (currentState === 'COMBAT') playerShip.x = e.clientX;
    handleTap(e);
});

// Game Loop
function gameLoop() {
    if (gameEnded) return;

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    const baseFontSize = Math.max(12, Math.floor(canvas.width / 28));

    // SCENE 1 & 2: INTRO SCROLL & AUDIO
    if (currentState === 'INTRO') {
        ctx.textAlign = 'center';
        let currentY = scrollY;
        const lineSpacing = baseFontSize * 1.5;

        for (let i = 0; i < rawParagraphs.length; i++) {
            const isTitle = (i === 0);
            const font = isTitle ? `bold ${Math.floor(baseFontSize * 1.2)}px monospace` : `${baseFontSize}px monospace`;
            const wrapped = wrapText(rawParagraphs[i], canvas.width * 0.85, font);

            ctx.font = font;
            ctx.fillStyle = isTitle ? '#ffaa00' : '#00ffcc';

            for (let line of wrapped) {
                if (currentY > -50 && currentY < canvas.height + 50) {
                    ctx.fillText(line, canvas.width / 2, currentY);
                }
                currentY += lineSpacing;
            }
        }
        scrollY -= 0.35;

        ctx.fillStyle = '#ffaa00';
        ctx.font = `${Math.max(11, Math.floor(baseFontSize * 0.9))}px monospace`;
        ctx.fillText(audio.introLore.paused ? "[ TAP TO START GAME ]" : "[ TAP TO SKIP TO DOCK ]", canvas.width / 2, canvas.height - 30);

    // SCENE 3 PART 1: DOCK MANAGER (dockmanager.png + TTS Sam)
    } else if (currentState === 'DOCK_MANAGER') {
        ctx.textAlign = 'center';
        if (images.dock.complete && images.dock.naturalWidth !== 0) {
            const size = Math.min(canvas.width * 0.75, 280);
            ctx.drawImage(images.dock, (canvas.width - size) / 2, canvas.height * 0.2, size, size);
        }

        ctx.fillStyle = '#ffaa00';
        ctx.font = `${Math.max(10, baseFontSize * 0.85)}px monospace`;
        ctx.fillText("[ TAP TO SKIP DIALOGUE ]", canvas.width / 2, canvas.height - 30);

    // SCENE 3 PART 2: STATION EXTERIOR (grok_image_xokn3wv.jpg + Docked at station)
    } else if (currentState === 'DOCK_EXTERIOR') {
        if (images.finalStation.complete && images.finalStation.naturalWidth !== 0) {
            ctx.drawImage(images.finalStation, 0, 0, canvas.width, canvas.height);
        }

        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(0, canvas.height - 90, canvas.width, 90);

        ctx.textAlign = 'center';
        ctx.fillStyle = '#00ffcc';
        ctx.font = `bold ${Math.max(12, baseFontSize)}px monospace`;
        ctx.fillText("DOCKED AT STATION", canvas.width / 2, canvas.height - 55);

        ctx.fillStyle = '#ffaa00';
        ctx.font = `${Math.max(11, baseFontSize)}px monospace`;
        ctx.fillText("[ TAP TO START MISSION ]", canvas.width / 2, canvas.height - 25);

    // SCENE 4: PRE-COMBAT 3RD PERSON SHIP
    } else if (currentState === 'PRE_COMBAT') {
        ctx.fillStyle = '#ffffff';
        for (let star of stars) {
            star.y += star.speed;
            if (star.y > 1) star.y = 0;
            ctx.fillRect(star.x * canvas.width, star.y * canvas.height, star.size, star.size);
        }

        if (images.ship.complete && images.ship.naturalWidth !== 0) {
            ctx.drawImage(images.ship, canvas.width / 2 - 40, canvas.height - 140, 80, 80);
        }

    // SCENE 5: COMBAT
    } else if (currentState === 'COMBAT') {
        ctx.fillStyle = '#ffffff';
        for (let star of stars) {
            star.y += star.speed;
            if (star.y > 1) star.y = 0;
            ctx.fillRect(star.x * canvas.width, star.y * canvas.height, star.size, star.size);
        }

        aiShip.x += aiShip.dirX;
        if (aiShip.x < 50 || aiShip.x > canvas.width - 50) {
            aiShip.dirX *= -1;
        }

        ctx.fillStyle = '#ff0033';
        ctx.beginPath();
        ctx.arc(aiShip.x, aiShip.y, aiShip.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();

        const aiBarW = 100;
        const aiBarH = 8;
        const aiBarX = aiShip.x - aiBarW / 2;
        const aiBarY = aiShip.y - aiShip.radius - 20;
        ctx.fillStyle = '#222222';
        ctx.fillRect(aiBarX, aiBarY, aiBarW, aiBarH);
        ctx.fillStyle = '#00ff66';
        ctx.fillRect(aiBarX, aiBarY, (aiShip.hp / aiShip.maxHp) * aiBarW, aiBarH);
        ctx.strokeStyle = '#ffffff';
        ctx.strokeRect(aiBarX, aiBarY, aiBarW, aiBarH);

        aiShootTimer++;
        if (aiShootTimer > 60) {
            playLaserSFX(200, 800);
            aiProjectiles.push({ x: aiShip.x, y: aiShip.y + aiShip.radius });
            aiShootTimer = 0;
        }

        ctx.fillStyle = '#00ffcc';
        for (let i = playerProjectiles.length - 1; i >= 0; i--) {
            let p = playerProjectiles[i];
            p.y -= 12;
            ctx.fillRect(p.x - 2, p.y, 4, 15);

            const dx = p.x - aiShip.x;
            const dy = p.y - aiShip.y;
            if (Math.sqrt(dx * dx + dy * dy) < aiShip.radius + 10) {
                aiShip.hp -= 34;
                playerProjectiles.splice(i, 1);

                if (aiShip.hp <= 0) {
                    currentState = 'EXPLOSION';
                    setTimeout(startPostCombatPipeline, 1000);
                }
            } else if (p.y < -20) {
                playerProjectiles.splice(i, 1);
            }
        }

        ctx.fillStyle = '#ff0033';
        for (let i = aiProjectiles.length - 1; i >= 0; i--) {
            let p = aiProjectiles[i];
            p.y += 8;
            ctx.fillRect(p.x - 2, p.y, 4, 15);

            if (Math.abs(p.x - playerShip.x) < 30 && Math.abs(p.y - playerShip.y) < 30) {
                playerShip.hp -= 25;
                aiProjectiles.splice(i, 1);

                if (playerShip.hp <= 0) {
                    handlePlayerDefeat();
                }
            } else if (p.y > canvas.height + 20) {
                aiProjectiles.splice(i, 1);
            }
        }

        if (images.ship.complete && images.ship.naturalWidth !== 0) {
            ctx.drawImage(images.ship, playerShip.x - 30, playerShip.y - 30, 60, 60);
        }

        const pBarW = 100;
        const pBarH = 8;
        const pBarX = playerShip.x - pBarW / 2;
        const pBarY = playerShip.y + 35;
        ctx.fillStyle = '#222222';
        ctx.fillRect(pBarX, pBarY, pBarW, pBarH);
        ctx.fillStyle = '#00ccff';
        ctx.fillRect(pBarX, pBarY, Math.max(0, (playerShip.hp / playerShip.maxHp)) * pBarW, pBarH);
        ctx.strokeStyle = '#ffffff';
        ctx.strokeRect(pBarX, pBarY, pBarW, pBarH);

    // PLAYER EXPLOSION
    } else if (currentState === 'PLAYER_EXPLOSION') {
        ctx.fillStyle = '#ffffff';
        for (let star of stars) {
            ctx.fillRect(star.x * canvas.width, star.y * canvas.height, star.size, star.size);
        }
        if (images.explosion.complete && images.explosion.naturalWidth !== 0) {
            ctx.drawImage(images.explosion, playerShip.x - 50, playerShip.y - 50, 100, 100);
        }

    // EJECTION CAPSULE DEPLOYED
    } else if (currentState === 'EJECTED') {
        ctx.fillStyle = '#ffffff';
        for (let star of stars) {
            star.y += star.speed * 0.5;
            if (star.y > 1) star.y = 0;
            ctx.fillRect(star.x * canvas.width, star.y * canvas.height, star.size, star.size);
        }

        ejectCapsuleY -= 0.5;
        ctx.fillStyle = '#cccccc';
        ctx.beginPath();
        ctx.arc(playerShip.x, ejectCapsuleY, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();

        ctx.textAlign = 'center';
        ctx.fillStyle = '#ff3333';
        ctx.font = `bold ${Math.max(12, baseFontSize)}px monospace`;
        ctx.fillText("SHIP DESTROYED - EJECTION CAPSULE DEPLOYED", canvas.width / 2, canvas.height - 60);

    // SCENE 6: TARGET DESTROYED
    } else if (currentState === 'EXPLOSION') {
        ctx.fillStyle = '#ffffff';
        for (let star of stars) {
            ctx.fillRect(star.x * canvas.width, star.y * canvas.height, star.size, star.size);
        }

        if (images.explosion.complete && images.explosion.naturalWidth !== 0) {
            ctx.drawImage(images.explosion, aiShip.x - 60, aiShip.y - 60, 120, 120);
        }

        if (images.ship.complete && images.ship.naturalWidth !== 0) {
            ctx.drawImage(images.ship, playerShip.x - 30, playerShip.y - 30, 60, 60);
        }

    // SCENE 7: POST COMBAT VOICE
    } else if (currentState === 'POST_COMBAT') {
        ctx.fillStyle = '#ffffff';
        for (let star of stars) {
            ctx.fillRect(star.x * canvas.width, star.y * canvas.height, star.size, star.size);
        }

        if (images.ship.complete && images.ship.naturalWidth !== 0) {
            ctx.drawImage(images.ship, playerShip.x - 30, playerShip.y - 30, 60, 60);
        }

    // SCENE 8: WARP SPEED WITH MYSHIP.PNG
    } else if (currentState === 'WARP') {
        ctx.strokeStyle = '#00ffff';
        ctx.lineWidth = 2;
        for (let star of stars) {
            star.y += star.speed * 8;
            if (star.y > 1) star.y = 0;
            ctx.beginPath();
            ctx.moveTo(star.x * canvas.width, star.y * canvas.height);
            ctx.lineTo(star.x * canvas.width, star.y * canvas.height + 40);
            ctx.stroke();
        }

        if (images.ship.complete && images.ship.naturalWidth !== 0) {
            ctx.drawImage(images.ship, canvas.width / 2 - 40, canvas.height - 140, 80, 80);
        }

    // SCENE 9: DOCKED AT STATION & MISSION BOARD
    } else if (currentState === 'FINAL') {
        if (images.finalStation.complete && images.finalStation.naturalWidth !== 0) {
            ctx.drawImage(images.finalStation, 0, 0, canvas.width, canvas.height);
        }

        ctx.fillStyle = 'rgba(0,0,0,0.75)';
        ctx.fillRect(0, canvas.height - 140, canvas.width, 140);

        ctx.textAlign = 'center';
        ctx.fillStyle = '#00ffcc';
        ctx.font = `bold ${Math.max(12, baseFontSize)}px monospace`;
        ctx.fillText("MISSION BOARD: MISSION 1 COMPLETED", canvas.width / 2, canvas.height - 105);

        ctx.fillStyle = '#ffaa00';
        ctx.font = `${Math.max(11, baseFontSize * 0.9)}px monospace`;
        ctx.fillText("[ TAP HERE TO REPLAY MISSION ]", canvas.width / 2, canvas.height - 65);

        ctx.fillStyle = '#ff3333';
        ctx.font = `${Math.max(11, baseFontSize * 0.9)}px monospace`;
        ctx.fillText("[ TAP HERE TO EXIT GAME ]", canvas.width / 2, canvas.height - 25);
    }

    requestAnimationFrame(gameLoop);
}

gameLoop();
